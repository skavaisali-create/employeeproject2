<?php
include 'connect.php';

$id = $_GET['id'];

$conn->query("DELETE FROM employees WHERE id=$id");
?>