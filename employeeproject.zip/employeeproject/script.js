function loadData() {
    fetch("fetch.php")
    .then(res => res.text())
    .then(data => {
        document.getElementById("employeeTable").innerHTML = data;
    });
}

document.getElementById("employeeForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let formData = new FormData(this);

    fetch("save.php", {
        method: "POST",
        body: formData
    }).then(() => {
        loadData();
        this.reset();
    });
});

function deleteData(id) {
    fetch("delete.php?id=" + id)
    .then(() => loadData());
}

window.onload = loadData;