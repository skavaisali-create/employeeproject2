<?php
include 'connect.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$dept = $_POST['department'];

$conn->query("INSERT INTO employees(name,email,phone,department)
VALUES('$name','$email','$phone','$dept')");
?>