<?php
$conn = new mysqli("localhost", "root", "", "employee_dp");

if($conn->connect_error){
    die("Connection failed");
}
?>