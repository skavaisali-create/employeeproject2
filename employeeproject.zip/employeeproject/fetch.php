<?php
include 'connect.php';

$result = $conn->query("SELECT * FROM employees");

while($row = $result->fetch_assoc()){
    echo "<tr>
        <td>{$row['name']}</td>
        <td>{$row['email']}</td>
        <td>{$row['phone']}</td>
        <td>{$row['department']}</td>
        <td>
            <button onclick='deleteData({$row['id']})'>Delete</button>
        </td>
    </tr>";
}
?>